// AvailabilityCheck.js
import React, { useState } from 'react';

const AvailabilityCheck = () => {
  const [selectedSeat, setSelectedSeat] = useState('');
  const [seatQuantity, setSeatQuantity] = useState(1);
  const [isAvailable, setAvailable] = useState(false);

  const seatFares = {
    front: 15,
    middle: 12,
    back: 10,
    upperSleeper: 20,
  };

  const checkAvailability = () => {
    // Simulate seat availability check logic
    // You can replace this with actual logic such as an API call to a backend
    setAvailable(true);
  };

  const handleSeatChange = (event) => {
    setSelectedSeat(event.target.value);
  };

  const handleQuantityChange = (event) => {
    setSeatQuantity(parseInt(event.target.value, 10));
  };

  const calculateFare = () => {
    if (selectedSeat) {
      return seatFares[selectedSeat] * seatQuantity;
    }
    return 0;
  };

  return (
    <div>
      <h2>Check Seat Availability</h2>

      <div>
        <label>Select Seat Type:</label>
        <select onChange={handleSeatChange} value={selectedSeat}>
          <option value="">Select Seat Type</option>
          {Object.keys(seatFares).map((seatType) => (
            <option key={seatType} value={seatType}>
              {seatType} - ${seatFares[seatType]}
            </option>
          ))}
        </select>
      </div>

      <div>
        <label>Select Quantity:</label>
        <input
          type="number"
          min="1"
          value={seatQuantity}
          onChange={handleQuantityChange}
        />
      </div>

      <button onClick={checkAvailability}>Check Available Seats</button>

      {isAvailable && selectedSeat ? (
        <p>
          {seatQuantity} {selectedSeat} seat(s) are available.
          Total Fare: ${calculateFare()}
        </p>
      ) : (
        <p>Please select a valid seat type and quantity.</p>
      )}
    </div>
  );
};

export default AvailabilityCheck;
