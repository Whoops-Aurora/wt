// App.js
import React, { useState } from 'react';
import './App.css';
import AvailabilityCheck from './AvailabilityCheck';
import RegistrationForm from './RegistrationForm';
import Confirmation from './Confirmation';

const App = () => {
  const [registrationData, setRegistrationData] = useState([]);
  const [totalFare, setTotalFare] = useState(0);

  const handleRegistration = (formData) => {
    setRegistrationData([...registrationData, formData]);
    // Calculate total fare (assuming a fixed amount for each passenger)
    setTotalFare(registrationData.length * 10); // Replace 10 with the actual fare per passenger
  };

  return (
    <div className="App">
      <AvailabilityCheck />
      <RegistrationForm onRegistration={handleRegistration} />
      {registrationData.length > 0 && <Confirmation passengers={registrationData} totalFare={totalFare} />}
    </div>
  );
};

export default App;
