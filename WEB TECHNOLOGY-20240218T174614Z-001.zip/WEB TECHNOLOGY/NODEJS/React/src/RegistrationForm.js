// RegistrationForm.js
import React, { useState } from 'react';

const RegistrationForm = ({ onRegistration }) => {
  const [formData, setFormData] = useState({
    name: '',
    source: '',
    destination: '',
  });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // Add form validation logic here
    // For simplicity, let's assume the form is always valid
    onRegistration(formData);
  };

  return (
    <div>
      <h2>Registration Form</h2>
      <form onSubmit={handleSubmit}>
        <label>
          Name:
          <input type="text" name="name" value={formData.name} onChange={handleChange} required />
        </label>
        <label>
          Source:
          <input type="text" name="source" value={formData.source} onChange={handleChange} required />
        </label>
        <label>
          Destination:
          <input type="text" name="destination" value={formData.destination} onChange={handleChange} required />
        </label>
        <button type="submit">Submit</button>
      </form>
    </div>
  );
};

export default RegistrationForm;
