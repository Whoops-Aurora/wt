// Confirmation.js
import React from 'react';

const Confirmation = ({ passengers, totalFare }) => {
  return (
    <div>
      <h2>Registration Successful</h2>
      <h3>Passenger Information:</h3>
      <ul>
      {passengers.map((passenger, index) => (
          <li key={index}>{passenger.quantity} {passenger.type} seat(s) for {passenger.name}</li>
        ))}
      </ul>
      <ul>
        {passengers.map((passenger, index) => (
          <li key={index}>{passenger.source}</li>
        ))}
      </ul>
      <ul>
        {passengers.map((passenger, index) => (
          <li key={index}>{passenger.destination}</li>
        ))}
      </ul>
      <p>Total Fare: ${totalFare}</p>
    </div>
  );
};

export default Confirmation;
