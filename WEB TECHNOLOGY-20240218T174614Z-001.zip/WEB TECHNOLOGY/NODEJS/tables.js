var mysql = require('mysql');

var con = mysql.createConnection({
  host: "127.0.0.1",
  user: "root",
  password: "",
  database: "test2"
});

con.connect(function(err) {
  if (err) throw err;
  console.log("Connected");

  var createUsersTable = "CREATE TABLE users (\
    user_id int(5),\
    username varchar(30),\
    email varchar(255)\
  )";

  con.query(createUsersTable, function(err, result) {
    if (err) throw err;
    console.log("Users table created");

   
    con.query("ALTER TABLE users ADD UNIQUE INDEX (user_id)", function(err, result) {
        if (err) throw err;
        console.log("Unique index added to user_id column");

 
    var createPostsTable = "CREATE TABLE posts (\
      post_id int(5) AUTO_INCREMENT PRIMARY KEY,\
      title varchar(255),\
      content text,\
      user_id int(5),\
      created_at datetime\
    )";

    con.query(createPostsTable, function(err, result) {
      if (err) throw err;
      console.log("Posts table created with auto-incrementing post_id");

      var createCommentsTable = "CREATE TABLE comments (\
        comment_id int(5),\
        post_id int(5),\
        user_id int(5),\
        comment_text text\
      )";

      con.query(createCommentsTable, function(err, result) {
        if (err) throw err;
        console.log("Comments table created");

        
      });
    });
  });
});
});
