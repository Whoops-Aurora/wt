var http= require('http');
http.createServer(function(req,res){
    res.writeHead(200,{'Content-Type': 'text/html'});
    res.write("<body bgcolor='cyan'>");
    res.write('Hello World');
    res.end("<h1>Good Afternoon</h1>");
    console.log("Connecting");
}).listen(8080);