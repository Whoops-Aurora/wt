var url=require('url');
var http=require('http');
var file=require('./with_test_2');

http.createServer(function(req,res){
    res.writeHead(200,{'Content-Type': 'text/html'});
    var q=url.parse(req.url,true).query;
    var a=q.a;
    var b=q.b;
    var r;
    a=parseInt(a);
    b=parseInt(b);
    
    res.write("The answer on addition is " + file.add(a,b) + '<br>');
    res.write("The answer on substraction is " + file.sub(a,b) + '<br>');
    res.write("The answer on multiplication is " + file.mul(a,b) + '<br>');
    res.write("The answer on divsion is " + file.div(a,b) + '<br>');
    
    res.end();
    console.log("Connecting to the webpage!!!");
}).listen(8080);