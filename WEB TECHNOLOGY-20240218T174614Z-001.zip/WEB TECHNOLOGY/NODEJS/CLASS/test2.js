var url=require('url');
var http=require('http');
http.createServer(function(req,res){
    res.writeHead(200,{'Content-Type': 'text/html'});
    var q=url.parse(req.url,true).query;
    var a=q.a;
    var b=q.b;
    a=parseInt(a);
    b=parseInt(b);
    var c=a+b;
    res.write("The answer is " +c);
    res.end();
    console.log("Connecting to the webpage!!!");
}).listen(8080);