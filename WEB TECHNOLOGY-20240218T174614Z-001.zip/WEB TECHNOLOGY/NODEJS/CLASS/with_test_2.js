exports.add=function(a,b)
{
    var c=a+b;
    return c;
}
exports.sub=function(a,b)
{
    var c=a-b;
    return c;
}
exports.mul=function(a,b)
{
    var c=a*b;
    return c;
}
exports.div=function(a,b)
{
    var c=a/b;
    return c;
}