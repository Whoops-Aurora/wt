// user.service.ts
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class UserService {
  private registeredUsers: any[] = [];

  registerUser(user: any) {
    this.registeredUsers.push(user);
  }

  getRegisteredUsers() {
    return this.registeredUsers;
  }
}
