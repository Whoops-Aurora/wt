// book.service.ts
import { Injectable } from '@angular/core';
import { Book } from './book.model';

@Injectable({
  providedIn: 'root',
})
export class BookService {
  private books: Book[] = [
    { id: 1, title: 'Book 1', price: 20 },
    { id: 2, title: 'Book 2', price: 25 },
    { id: 3, title: 'Book 3', price: 30 },
  ];

  getBooks(): Book[] {
    return this.books;
  }
}
