// shopping-cart.component.ts
import { Component } from '@angular/core';
import { BookService } from '../book.service';

@Component({
  selector: 'app-shopping-cart',
  templateUrl: './shopping-cart.component.html',
  styleUrls: ['./shopping-cart.component.css'],
})
export class ShoppingCartComponent {
  books: any[] = [];

  constructor(private bookService: BookService) {
    this.books = this.bookService.getBooks();
  }

  cart: any[] = [];

  addToCart(book: any) {
    this.cart.push(book);
  }

  getTotalBill() {
    return this.cart.reduce((sum, book) => sum + book.price, 0);
  }
}
