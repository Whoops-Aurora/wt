const express = require('express');
const bodyParser = require('body-parser');
const mysql = require('mysql');

const app = express();
const port = 3001;

app.use(bodyParser.urlencoded({ extended: true }));

const con = mysql.createConnection({
    host: "127.0.0.1",
    user: "root",
    password: "",
    database: "test2"
});

con.connect(function (err) {
    if (err) throw err;
    console.log("Connected to MySQL database");
});

app.get('/', (req, res) => {
    res.sendFile(__dirname + '/index.html');
});

app.post('/newPost', (req, res) => {
    const title = req.body.title;
    const content = req.body.content;
    const username = req.body.username;
    const email = req.body.email;
    const user_id = req.body.user_id; // Get user ID from form input
  

    
    // Inserting user into users and posts table
  con.query("INSERT INTO users (user_id, username, email) VALUES (?, ?, ?)", [user_id, username, email], (err, result) => {
    if (err) throw err;

    
    const createPostQuery = "INSERT INTO posts (title, content, user_id, created_at) VALUES (?, ?, ?, NOW())";
    con.query(createPostQuery, [title, content, user_id], function (err, result) {
      if (err) throw err;
      console.log("Post created");
      res.send('Post created successfully');
      });
    });
  });
  

  app.get('/posts', (req, res) => {
    const retrievePostsQuery = "SELECT posts.post_id, posts.title, posts.content, posts.created_at, users.username FROM posts JOIN users ON posts.user_id = users.user_id ORDER BY posts.created_at DESC LIMIT 5";
  
    con.query(retrievePostsQuery, (err, results) => {
      if (err) throw err;
  
      const posts = results;
      res.send(posts);
    });
  });

  // Getting the latest post ID
app.get('/getPostId', (req, res) => {
    con.query('SELECT MAX(post_id) FROM posts', (err, results) => {
      if (err) throw err;
      const postId = results[0]['MAX(post_id)'];
      res.send(postId);
    });
  });
  
  // Adding comment to the latest post
app.post('/newComment', (req, res) => {
    const comment_id = req.body.comment_id;
    const comment_text = req.body.comment_text;
  
    // Getting the latest post ID from the database
    con.query('SELECT MAX(post_id) FROM posts', (err, results) => {
      if (err) throw err;
      const postId = results[0]['MAX(post_id)'];
  
      const user_id = req.body.user_id; // Get user ID from form input (assuming it's available)
  
      const insertCommentQuery = "INSERT INTO comments (comment_id, comment_text, post_id, user_id, created_at) VALUES (?, ?, ?, ?, NOW())";
      con.query(insertCommentQuery, [comment_id, comment_text, postId, user_id], (err, result) => {
        if (err) throw err;
        console.log("Comment added");
        res.send('Comment added successfully');
      });
    });
  });

  // deleting
app.post('/deleteComment', (req, res) => {
    const comment_id = req.body.comment_id;
  
    const deleteCommentQuery = "DELETE FROM comments WHERE comment_id = ?";
    con.query(deleteCommentQuery, [comment_id], (err, result) => {
      if (err) throw err;
      console.log("Comment deleted");
      res.send('Comment deleted successfully');
    });
  });


// retrieving comments 
app.get('/getComments', (req, res) => {
    const postId = req.query.post_id;
  
    const retrieveCommentsQuery = "SELECT comment_id, comment_text, user_id, created_at FROM comments WHERE post_id = ?";
    con.query(retrieveCommentsQuery, [postId], (err, comments) => {
      if (err) throw err;
      res.send(comments);
    });
  });
  
  
  


app.listen(port, () => {
    console.log(`Server listening at http://localhost:${port}`);
});